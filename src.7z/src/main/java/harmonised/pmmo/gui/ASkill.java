package harmonised.pmmo.gui;

public class ASkill
{
	public double xp, pos, goalXp, goalPos, bonus = 0;
	ASkill( double xp, double pos, double goalXp, double goalPos )
	{
		this.xp = xp;
		this.pos = pos;
		this.goalXp = goalXp;
		this.goalPos = goalPos;
	}
}
