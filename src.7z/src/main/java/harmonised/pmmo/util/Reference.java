package harmonised.pmmo.util;

public class Reference 
{
	public static final String MOD_ID = "pmmo";
	public static final String NAME = "Project MMO";
	public static final String ACCEPTED_VERSIONS = "[1.16.1]";
}
