package harmonised.pmmo.events;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;

public class PickupHandler
{
//    public static void handlePickup( EntityItemPickupEvent event )
//    {
//        ItemStack itemStack = event.getItem().getItem();
//        CompoundNBT writeData = new CompoundNBT();
//        CompoundNBT test = itemStack.serializeNBT();
//
//        System.out.println( itemStack.serializeNBT().contains( "owner" ) );
//
//        writeData.putString( "owner", event.getPlayer().getUniqueID().toString() );
//
//
//        System.out.println( itemStack.serializeNBT().contains( "owner" ) );
//    }
}
